﻿$(document).ready(function () {
    function countChar(val) {
        var len = val.value.length;
        console.log(len);
        $("#Count").value = len;
    };
});