INSERT INTO 
			Cuenta (Email, Contrasena)
		Values
			("ruvalcaba_alberto@hotmail.com","Ruvalcaba95"),
            ("email2@correo.com","1234"),
            ("email3@correo.com","12345"),
            ("email4@correo.com","123456"),
            ("email5@correo.com","1234567");
			
		