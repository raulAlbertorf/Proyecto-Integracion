INSERT INTO 
			Reporte (Id, Perfil_Id, Fecha, Incidente, Descripcion, UltimaModificacion, Ubicacion_Id)
		Values
			(1, 1, NOW(), 2, "Descripcion1", NOW(), 1),
            (2, 1, NOW(), 3, "Descripcion2", NOW(), 1),
            (3, 1, NOW(), 4, "Descripcion3", NOW(), 2),
            (4, 1, NOW(), 1, "Descripcion4", NOW(), 2),
            (5, 2, NOW(), 2, "Descripcion5", NOW(), 2),
            (6, 2, NOW(), 3, "Descripcion6", NOW(), 1),
            (7, 2, NOW(), 4, "Descripcion7", NOW(), 1),
            (8, 2, NOW(), 1, "Descripcion8", NOW(), 1),
            (9, 3, NOW(), 4, "Descripcion9", NOW(), 1),
            (10, 4, NOW(), 1, "Descripcion10", NOW(), 1),
            (11, 5, NOW(), 4, "Descripcion11", NOW(), 1),
            (12, 5, NOW(), 1, "Descripcion12", NOW(), 2);
		