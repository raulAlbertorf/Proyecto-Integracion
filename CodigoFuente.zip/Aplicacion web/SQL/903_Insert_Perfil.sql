INSERT INTO 
			Perfil (Id, Nombre, UrlImagen, Cuenta_Email, Ubicacion_Id)
		Values
			(1, "Perfil1", NULL, "ruvalcaba_alberto@hotmail.com", 1),
            (2, "Perfil2", NULL, "email2@correo.com", 1),
            (3, "Perfil3", NULL, "email3@correo.com", 2),
            (4, "Perfil4", NULL, "email4@correo.com", 2),
            (5, "Perfil5", NULL, "email5@correo.com", 2);
			
		