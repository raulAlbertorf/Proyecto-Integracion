INSERT INTO 
			Ubicacion (Id, Latitude, Longitude)
		Values
			(1, 19.502550, -99.187258),
            (2, 12.344332, 12.12433),
            (3, 19.021213, 32.21210);
			