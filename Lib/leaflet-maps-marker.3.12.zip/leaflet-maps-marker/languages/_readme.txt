The according .po-files have been removed from the plugin�s distribution to keep the plugin�s size smaller.
Nethertheless you can download the current .po & .mo-files at any time at https://translate.mapsmarker.com/projects/lmm
At this site, you can also suggest updated or new translations to be included in the official release.